# WhatsApp Bug Tool

Tool ini digunakan untuk pentest bug WhatsApp seperti CrashWA, InvisDelay, FC-Reyx, dan Invis.

## Fitur
- Kirim bug via server tanpa membuka WhatsApp
- Gunakan Baileys + Pairing QR Code
- Frontend HTML sederhana

## Cara Jalankan
1. `npm install`
2. `node server.js`
3. Scan QR di terminal
